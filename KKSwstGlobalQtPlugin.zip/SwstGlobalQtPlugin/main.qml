import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.qfield // Fehler bei QT-Creator (Module nicht in QT-C integriert)
import org.qgis // Fehler bei QT-Creator (Module nicht in QT-C integriert)
import Theme // Fehler bei QT-Creator (Module nicht in QT-C integriert)

import "qrc:/qml" as QFieldItems

// Import JS-Datein
import "scripts/Logic.js" as Logic

// QML-JS Content mit: "setContextProperty, qmlRegisterType, qmlRegisterSingletonType"

Item
{
    id: plugin

    // Variables
    property string logText: ""
    signal logMessage(string message)

    // Zugriff auf QField-API
    property var mainWindow: iface.mainWindow()

    Component.onCompleted:
    {
        mainWindow.displayToast("SwstGlobalQtPlugin geladen...")
        iface.addItemToPluginsToolbar(logButton)
        iface.addItemToPluginsToolbar(exportButton)
        //iface.addItemToPluginsToolbar(importButton)

        var checkServerAdress = settings.value("serveradress", "").toString();
        var checkToken = settings.value("token", "").toString();

        if(!checkServerAdress || !checkToken)
        {
            firstSettingDialog.open()
        }

        Logic.setLogCallback(function refreshGUI(msg)
        {
            logTextBox.append(msg)
        })
    }

    // firstAppStart Menü (Grundeinstellung)
    Dialog
    {
        id: firstSettingDialog
        parent: mainWindow.contentItem

        title: "Grundeinstellungen"
        visible: false
        modal: true
        font: Theme.defaultFont

        z: 10000
        width: 430
        height: 330
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2

        ColumnLayout
        {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 15

            // Server
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "Server:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstServerAdr
                    Layout.fillWidth: true
                    placeholderText: "Adresse eingeben"
                }
            }

            // Token
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "Token:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstApiToken
                    Layout.fillWidth: true
                    placeholderText: "Token eingeben"
                }
            }

            // Monteur
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label { text: "Monteur:"; Layout.preferredWidth: 80 }

                ComboBox
                {
                    id: firstComboBox
                    Layout.fillWidth: true
                    textRole: "key"
                    valueRole: "value"

                    model: firstUserModel

                    Component.onCompleted:
                    {
                        mainWindow.displayToast("Monteure werden synchronisiert...")
                        getSyncUser()
                    }

                    ListModel
                    {
                        id: firstUserModel
                    }
                }
            }

            // Buttons zentriert
            RowLayout
            {
                Layout.alignment: Qt.AlignHCenter
                spacing: 20

                Button
                {
                    text: "Abbrechen"
                    onClicked: firstSettingDialog.close()
                }

                Button
                {
                    text: "Speichern"
                    onClicked:
                    {
                        saveBasicSettings();
                    }
                }
            }
        }
    }

    // Einstellungs Menü
    Dialog
    {
        id: settingDialog
        parent: mainWindow.contentItem

        title: "Einstellungen & Log"
        visible: false
        modal: true
        font: Theme.defaultFont

        z: 10000
        width: 390
        height: 440
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2

        ScrollView
        {
            anchors.fill: parent
            contentWidth: parent.width
            contentHeight: columnContent.height

            ColumnLayout
            {
                id: columnContent
                width: parent.width
                spacing: 20
                anchors.margins: 20

                // ================= Settings Bereich =================
                ColumnLayout
                {
                    Layout.fillWidth: true
                    spacing: 10

                    Label { text: "Einstellungen"; font.bold: true; font.pointSize: 14 }
                    Rectangle { height: 1; color: "#888"; Layout.fillWidth: true }

                    // Server
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Server:"; Layout.preferredWidth: 80 }
                        TextField { id: serverField; Layout.fillWidth: true; placeholderText: "Adresse eingeben" }
                    }

                    // Token
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Token:"; Layout.preferredWidth: 80 }
                        TextField { id: apiTokenField; Layout.fillWidth: true; placeholderText: "Token eingeben" }
                    }

                    // Monteur
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Monteur:"; Layout.preferredWidth: 80 }

                        ComboBox
                        {
                            id: comboBox
                            Layout.fillWidth: true
                            textRole: "key"
                            valueRole: "value"

                            model: userModel

                            ListModel
                            {
                                id: userModel
                            }
                        }
                    }

                    // lastEditDateField
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Letzte\nÄnderung:"; wrapMode: Text.WordWrap; Layout.preferredWidth: 80 }
                        TextField { id: lastEditDateField; Layout.fillWidth: true; placeholderText: "Letzte Änderung"; readOnly: true }
                    }

                    // Buttons Settings
                    RowLayout
                    {
                        Layout.alignment: Qt.AlignHCenter
                        spacing: 20

                        Button
                        {
                            text: "Abbrechen"
                            onClicked: settingDialog.close()
                        }

                        Button
                        {
                            text: "Speichern"
                            onClicked:
                            {
                                saveSettings();
                            }
                        }
                    }
                }

                // ================= Log Bereich =================
                ColumnLayout
                {
                    Layout.fillWidth: true
                    spacing: 10

                    Label { text: "Log"; font.bold: true; font.pointSize: 14 }
                    Rectangle { height: 1; color: "#888"; Layout.fillWidth: true }

                    ScrollView
                    {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 200

                        TextArea
                        {
                            id: logTextBox
                            wrapMode: Text.WordWrap
                            readOnly: true
                            text: ""
                            width: parent.width
                        }
                    }

                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Button
                        {
                            text: "Verbindungstest"
                            Layout.fillWidth: true
                            onClicked: syncData()
                        }

                        Button
                        {
                            text: "Schließen"
                            Layout.fillWidth: true
                            onClicked: settingDialog.close()
                        }
                    }
                }
            }
        }
    }

    // Button Logfensters
    QfToolButton
    {
        id: logButton
        bgcolor: Theme.darkGray
        iconSource: "ressource/plSettings.svg"
        iconColor: "white"
        round: true
        onClicked:
        {
            //mainWindow.displayToast("logButton wurde geklickt")

            getSettings()
            settingDialog.open()
        }
    }

    // Button Export
    QfToolButton
    {
        id: exportButton
        bgcolor: Theme.darkGray
        iconSource: 'ressource/plSync.svg'
        iconColor: "white"
        round: true
        onClicked:
        {
            mainWindow.displayToast("Synchronisierung wird ausgeführt...")
            syncData()
        }
    }

    // Button Import
    /*QfToolButton
    {
        id: importButton
        bgcolor: Theme.lightGray
        iconSource: Theme.getThemeVectorIcon("ic_info_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked:
        {
            mainWindow.displayToast("importButton wurde geklickt")
            importData()
        }
    }*/

// ###################################################### FUNCTIONS ###################################################### //

    function saveBasicSettings()
    {
        var serverAdress = firstServerAdr.text;
        var username = firstComboBox.currentText;
        var apitoken = firstApiToken.text;

        if (serverAdress && apitoken)
        {
            settings.setValue("serveradress", serverAdress);
            settings.setValue("username", username);
            settings.setValue("token", apitoken);
            settings.sync();
            firstSettingDialog.close();
            mainWindow.displayToast("Einstellungen wurden gespeichert!");
        }
        else
        {
            mainWindow.displayToast("Speichern fehlgeschlagen, alle Felder müssen ausgefüllt sein!");
        }
    }

    function saveSettings()
    {
        var serverName = serverField.text;
        var username = comboBox.currentText;
        var apitoken = apiTokenField.text;

        if (serverName && username && apitoken)
        {
            settings.setValue("serveradress", serverName);
            settings.setValue("username", username);
            settings.setValue("token", apitoken);
            settings.sync();
            settingDialog.close();
            mainWindow.displayToast("Einstellungen wurden gespeichert!");
        }
        else
        {
            mainWindow.displayToast("Speichern fehlgeschlagen, alle Felder müssen ausgefüllt sein!");
        }
    }

    function getSettings()
    {
        serverField.text = settings.value("serveradress", "");
        apiTokenField.text = settings.value("token", "");
        lastEditDateField.text = settings.value("lasteditdate", "");

        // gespeicherten User wieder in ComboBox setzen
        var savedUser = settings.value("username", "");
        for (var i = 0; i < comboBox.count; i++)
        {
            var item = comboBox.model.get(i);
            if (item.key === savedUser)
            {
                comboBox.currentIndex = i;
                break;
            }
        }

        settings.sync();
    }

    function getSyncUser()
    {
        var serverAdress = settings.value("serveradress", "");
        var newAdress = serverAdress + "?MethodName=SyncUser";

        // Create a http httpRequest
        var httpRequest = new XMLHttpRequest();

        httpRequest.open("POST", newAdress, true);
        httpRequest.timeout = 5000;

        httpRequest.onreadystatechange = function()
        {
            if (httpRequest.readyState === XMLHttpRequest.DONE)
            {
                if (httpRequest.status >= 200 && httpRequest.status <= 405)
                {
                    var response = JSON.parse(httpRequest.responseText);

                    for(var i = 0; i < response.Items.length; i++)
                    {
                        userModel.append
                        ({
                             key: response.Items[i].key,
                             value: response.Items[i].value
                        });
                    }

                    for(var j = 0; j < response.Items.length; j++)
                    {
                        firstUserModel.append
                        ({
                             key: response.Items[j].key,
                             value: response.Items[j].value
                        });
                    }
                }

                else
                {
                    Logic.logToGui("Monteur synchronisierung: " + httpRequest.status, 3);
                    Logic.logToGui("Fehler: " + httpRequest.statusText, 1);
                }
            }
        };

        httpRequest.send();
    }

    function applyServerUpdates(records)
    {
        const layers = qgisProject.mapLayersByName("Hydrant_VN");
        const layer = layers.length > 0 ? layers[0] : null;

        if (!layer)
        {
            Logic.logToGui("Layer 'Hydrant_VN' nicht gefunden!", 3);
            return;
        }

        if (!layer.startEditing())
        {
            Logic.logToGui("Konnte Layer nicht zum Bearbeiten öffnen.", 3);
            return;
        }

        var id = 0;
        while (true)
        {
            const myObject = layer.getFeature(id);

            const breakCheck = myObject.attribute("G3E_FID");
            if (!breakCheck)
            {
                Logic.logToGui("Alle lokalen Objekte wurden überprüft. ID zuletzt: " + id, 2);
                break;
            }

            const localFID = myObject.attribute("G3E_FID");

            var matchingRecord = null;
            for (var i = 0; i < records.length; i++)
            {
                const serverFID = String(records[i].g3e_fid).trim();
                const localFIDStr = String(localFID).trim();

                if (serverFID === localFIDStr && records[i].changeItem === true)
                {
                    //Logic.logToGui("Item wurde gefunden: " + localFID, 1);
                    matchingRecord = records[i];
                    break;
                }
            }

            if (matchingRecord)
            {
                const featureId = myObject.id;

                layer.changeAttributeValue(featureId, layer.fields.indexOf("BEZEICHNUN"), matchingRecord.bezeichnung);
                layer.changeAttributeValue(featureId, layer.fields.indexOf("LAGE_ZUM_S"), matchingRecord.lage_zum_s);
                layer.changeAttributeValue(featureId, layer.fields.indexOf("LAGEGENAUI"), matchingRecord.lagegenaui);
                layer.changeAttributeValue(featureId, layer.fields.indexOf("WARTUNG"), matchingRecord.wartung);

                Logic.logToGui("Objekt mit FID " + localFID + " aktualisiert.", 1);
            }

            id++;
        }

        if (!layer.commitChanges())
        {
            Logic.logToGui("Fehler beim Speichern der Änderungen.", 3);
        }

        Logic.logToGui("Synchronisierung abgeschlossen.", 2);
    }

    function syncData()
    {
        Logic.logToGui("Synchronisierung gestartet.", 2);

        // Projekt/Grunddaten abrufen
        var directory = qgisProject.fileName;
        var path = directory.split("/");
        var projectName = path[path.length - 1];
        var userid = comboBox.currentValue;
        var user = comboBox.currentText;
        var apitoken = settings.value("token", "");

        // ####### Abruf der Schicht ####### //

        var layers = qgisProject.mapLayersByName("Hydrant_VN");
        var layer = layers.length > 0 ? layers[0] : null;

        if(layer)
        {
 //           Logic.logToGui("Projekt: " + projectName, 1);
 //           Logic.logToGui("Schicht gefunden: " + layer, 1);
        }

        if (layer.fields && layer.fields.names)
        {
            var fieldNames = layer.fields.names;
//            Logic.logToGui("Abruf der aktuellen Schichten erfolgreich!", 2);
//            Logic.logToGui("Feldnamen: " + fieldNames.join(", "), 1);
        }

        // ####### Abruf der Details ####### //

//        Logic.logToGui("Details der Schicht werden abgerufen...", 2);

        var records = [];
        var id = 0;
        var maxID = 5;

        while(true)
        {
            const myObject = layer.getFeature(id);
            //getMaintenanceStatus(myObject, id); // Für´s updaten des Status (Falls nicht Serverabhänigkeit)

            const breakCheck = myObject.attribute("G3E_FID"); // Prüfung auf weitere IDs (Schleife beenden)
            if (!breakCheck)
            {
                Logic.logToGui("Alle verfügbaren Objekte gefunden... (" + id + ")", 2);
                break;
            }

            const filter = myObject.attribute("Wartung"); // Filterfunktion
            if (filter !== undefined)
            {
                const objektFields = myObject.fields;
                if (objektFields !== null)
                {
                    //Logic.logToGui("myObject objektFields.count: " + objektFields.count, 1);
                } else
                {
                    Logic.logToGui("Keine Felder gefunden...", 3);
                }

                // Daten aus den Feldern
                var fidValue = myObject.attribute("G3E_FID"); // #1
                var bezeichnungValue = myObject.attribute("BEZEICHNUN"); // #2
                var lage_zum_sValue = myObject.attribute("LAGE_ZUM_S"); // #3
                var dateValue = Logic.convertOnceDateFormat(myObject.attribute("SyncDate")); // #4
                var statusValue = myObject.attribute("Wartung"); // #5
                var changeItemValue = myObject.attribute("changeItem"); // #6

                if(dateValue === Logic.convertOnceDateFormat(new Date()))
                {
                    myObject.setAttribute("changeItem", "true"); // Update des Wertes (Bei Änderungen)
                    changeItemValue = myObject.attribute("changeItem"); // Aktualisierter Wert abrufen

                    settings.setValue("lasteditdate", Logic.convertOnceDateFormat(new Date()));
                    settings.sync();
                }

                records.push
                ({
                    g3e_fid: fidValue,
                    bezeichnung: bezeichnungValue,
                    lage_zum_s: lage_zum_sValue,
                    lasteditby: userid,
                    syncdate: dateValue,
                    wartung: statusValue,
                    changeitem: changeItemValue
                });
            }

            id++;
        }

        // ############### Daten sammeln & Speichern ############### //

        var basicDate = settings.value("lasteditdate", "") || null

        var basicDataList =
        {
            ProjectName: projectName,
            UserID: userid,
            UserName: user,
            Token: apitoken,
            Syncdate: basicDate,
            Records: records
        };

        // ############### Daten sammeln & Speichern ############### //

        var serverAdress = settings.value("serveradress", "");
        var jsonString = JSON.stringify(basicDataList);

        // Ausgabe
        Logic.logToGui("Daten wurden gespeichert...", 2);
        //Logic.logToGui(jsonString, 1);

        // Serververbindung (Daten)
        Logic.connectData(serverAdress, jsonString);
    }
}
