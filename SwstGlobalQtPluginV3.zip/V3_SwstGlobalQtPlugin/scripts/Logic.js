// Ablauf zum setzen eines Loggers #LOG#
var logCallback = null;

// Setzt die Funktion vom Component.onCompleted ein
function setLogCallback(callback)
{
    logCallback = callback;
}

// Ruft setLogText auf & übergibt den Return an "refreshGUI"
function logToGui(message, status)
{
    if (logCallback)
    {
        logCallback(setLogText(message, status));
    }
}

// Holt den Zeitstempel & setzt die Lognachricht + Rückgabe
function setLogText(message, status)
{
    if(typeof status == "number")
    {
        switch(status)
        {
        case 1:
            return getLogStamp() + " - [INFO] " + message;
        case 2:
            return getLogStamp() + " - [WARNING] " + message;
        case 3:
            return getLogStamp() + " - [ERROR] " + message;
        default:
            return getLogStamp() + " - [UNKNOWN] " + message;
        }
    }
    else
    {
        return getLogStamp() + " - [ERROR] Fehler bei der Logausgabe aufgetreten!";
    }
}

// Aktuelles Datum im DE-Format
function getLogStamp()
{
    var date = new Date();

    return date.toLocaleDateString("de-DE")
}

// Umwandlung des ISO-Dates in GUI-Ansicht
function getTimeStamp(str)
{
    var d = new Date(str);
    if (isNaN(d.getTime())) return null;

    var date = d.toLocaleDateString("de-DE");
    var hours = String(d.getHours()).padStart(2, '0');
    var minutes = String(d.getMinutes()).padStart(2, '0');
    var seconds = String(d.getSeconds()).padStart(2, '0');

    return `${date} ${hours}:${minutes}:${seconds}`;
}

function toIsoDateTime(str) // ISO-Format + Zeit (Übergabe ggf. Online-Quelle)
{
  if (!str || typeof str !== 'string') return null;

  str = str.trim();

  // z. B. "15.10.23 14:30:26"
  if (str.includes(' '))
  {
    const [d, t] = str.split(' ');
    // Teilt Datum & Uhrzeit: ["15.10.23", "14:30:26"]

    let [day, month, year] = d.split('.').map(Number);
    // Extrahiert Tag, Monat, Jahr → [15, 10, 23]

    if (year < 100) year += 2000;
    // "2023"

    const [h, m, s = 0] = t.split(':').map(Number);
    // [14, 30]

    // Baut ISO-Format zusammen
    return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}T${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
}

// Serverstatus prüfen
function serverAvailable(serverAdress, callback)
{
    var httpRequest = new XMLHttpRequest();
    httpRequest.open("GET", serverAdress, true);
    httpRequest.timeout = 15000;
    httpRequest.setRequestHeader("Content-Type", "application/json");
    logToGui("Verbindung zum Server wird hergestellt...", 1);

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === httpRequest.DONE)
        {
            if (httpRequest.status === 200)
            {
                logToGui("Serververbindung erfolgreich!", 1);
                callback(true);
            }
            else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.statusText, 1);
                callback(false);
            }
        }
    };

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
        callback(false);
    };

    httpRequest.send();
}

// Client-Daten an Server übermitteln
function connectData(serverAdress, token, jsonString)
{
    var newAdress = serverAdress + "DesktopModules/SWSTQFieldWS/API/QFieldDataRecord/";

    // Create a http httpRequest
    var httpRequest = new XMLHttpRequest();

    httpRequest.open("POST", newAdress, true);
    httpRequest.timeout = 15000;

    httpRequest.setRequestHeader("Content-Type", "application/json");
    httpRequest.setRequestHeader("Authorization", "Bearer " + token);

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === XMLHttpRequest.DONE)
        {
            if (httpRequest.status === 200)
            {
                logToGui("Verbindung erfolgreich hergestellt!", 1);

                var response = JSON.parse(httpRequest.responseText);
                var syncdate = response.SyncDate;
                var records = response.Records;

                applyServerUpdates(syncdate, records);
            }

            else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.statusText, 1);
            }
        }
    };

    httpRequest.send(jsonString);

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
    };
}



