import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.qfield // Fehler bei QT-Creator (Module nicht in QT-C integriert)
import org.qgis // Fehler bei QT-Creator (Module nicht in QT-C integriert)
import Theme // Fehler bei QT-Creator (Module nicht in QT-C integriert)

import "qrc:/qml" as QFieldItems

// Import JS-Datein
import "scripts/Logic.js" as Logic

// QML-JS Content mit: "setContextProperty, qmlRegisterType, qmlRegisterSingletonType"

Item
{
    id: plugin

    // Zugriff auf QField-API
    property var mainWindow: iface.mainWindow()

    // Main beim Start
    Component.onCompleted:
    {
        mainWindow.displayToast("SwstGlobalQtPlugin geladen...")
        iface.addItemToPluginsToolbar(logButton)
        iface.addItemToPluginsToolbar(syncButton)

        var checkServerAdress = settings.value("serveradress", "").toString();
        var checkToken = settings.value("token", "").toString();

        if(!checkServerAdress || !checkToken)
        {
            firstSettingDialog.open()
        }
        else
        {
            // User abrufen
            getSyncUser()
        }

        // Speicherung der "refreshGUI" Funkion in logCallBack
        Logic.setLogCallback(function refreshGUI(msg)
        {
            logTextBox.append(msg)
        })
    }

    // firstAppStart Menü (Grundeinstellung)
    Dialog
    {
        id: firstSettingDialog // Vergibt eine eindeutige ID für den Zugriff im Code
        parent: mainWindow.contentItem // Setzt den übergeordneten Container (Positionierung im Hauptfenster)

        title: "Grundeinstellungen" // Titel des Dialogs, der oben angezeigt wird
        visible: false // Dialog ist beim Start unsichtbar
        modal: true // Blockiert Interaktionen mit anderen UI-Elementen, solange geöffnet
        font: Theme.defaultFont // Setzt die Schriftart auf die Standard-Schrift des Themes

        z: 10000 // Legt die Z-Ordnung fest (hoher Wert = ganz oben im Stack)
        width: 430 // Breite des Dialogs in Pixeln
        height: 330 // Höhe des Dialogs in Pixeln
        x: (parent.width - width) / 2 // Zentriert den Dialog horizontal im Parent
        y: (parent.height - height) / 2 // Zentriert den Dialog vertikal im Parent

        ColumnLayout
        {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 15

            // Server
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "Server:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstServerAdr
                    Layout.fillWidth: true
                    placeholderText: "Adresse eingeben"
                }
            }

            // Token
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "Token:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstApiToken
                    Layout.fillWidth: true
                    placeholderText: "Token eingeben"
                }
            }

            // Buttons zentriert
            RowLayout
            {
                Layout.alignment: Qt.AlignHCenter
                spacing: 20

                Button
                {
                    text: "Abbrechen"
                    onClicked: firstSettingDialog.close()
                }

                Button
                {
                    text: "Speichern"
                    onClicked:
                    {
                        saveBasicSettings();
                    }
                }
            }
        }
    }

    // Einstellungs Menü
    Dialog
    {
        id: settingDialog              // Vergibt eine eindeutige ID für den Zugriff im Code

        parent: mainWindow.contentItem // Setzt den übergeordneten Container (Positionierung im Hauptfenster)

        title: "Einstellungen & Log"   // Titel des Dialogs, der oben angezeigt wird
        visible: false                 // Dialog ist beim Start unsichtbar
        modal: true                    // Blockiert Interaktionen mit anderen UI-Elementen, solange geöffnet
        font: Theme.defaultFont        // Setzt die Schriftart auf die Standard-Schrift des Themes

        z: 10000                       // Legt die Z-Ordnung fest (hoher Wert = ganz oben im Stack)
        width: 390                     // Breite des Dialogs in Pixeln
        height: 440                    // Höhe des Dialogs in Pixeln
        x: (parent.width - width) / 2 // Zentriert den Dialog horizontal im Parent
        y: (parent.height - height) / 2 // Zentriert den Dialog vertikal im Parent

        ScrollView
        {
            anchors.fill: parent
            contentWidth: parent.width
            contentHeight: columnContent.height

            ColumnLayout
            {
                id: columnContent
                width: parent.width
                spacing: 20
                anchors.margins: 20

                // ================= Settings Bereich =================
                ColumnLayout
                {
                    Layout.fillWidth: true
                    spacing: 10

                    Label { text: "Einstellungen"; font.bold: true; font.pointSize: 14 }
                    Rectangle { height: 1; color: "#888"; Layout.fillWidth: true }

                    // Server
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Server:"; Layout.preferredWidth: 80 }
                        TextField { id: serverField; Layout.fillWidth: true; placeholderText: "Adresse eingeben" }
                    }

                    // Token
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Token:"; Layout.preferredWidth: 80 }
                        TextField { id: apiTokenField; Layout.fillWidth: true; placeholderText: "Token eingeben" }
                    }

                    // Monteur
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Monteur:"; Layout.preferredWidth: 80 }

                        ComboBox
                        {
                            id: comboBox
                            Layout.fillWidth: true
                            textRole: "display"
                            valueRole: "value"

                            model: userModel

                            ListModel
                            {
                                id: userModel
                            }
                        }
                    }

                    // lastEditDateField
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Letzte\nÄnderung:"; wrapMode: Text.WordWrap; Layout.preferredWidth: 80 }
                        TextField { id: lastEditDateField; Layout.fillWidth: true; placeholderText: "Letzte Änderung"; readOnly: true }
                    }

                    // Buttons Settings
                    RowLayout
                    {
                        Layout.alignment: Qt.AlignHCenter
                        spacing: 20

                        Button
                        {
                            text: "Abbrechen"
                            onClicked: settingDialog.close()
                        }

                        Button
                        {
                            text: "Speichern"
                            onClicked:
                            {
                                saveSettings();
                            }
                        }
                    }
                }

                // ================= Log Bereich =================
                ColumnLayout
                {
                    Layout.fillWidth: true
                    spacing: 10

                    Label { text: "Log"; font.bold: true; font.pointSize: 14 }
                    Rectangle { height: 1; color: "#888"; Layout.fillWidth: true }

                    ScrollView
                    {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 200

                        TextArea
                        {
                            id: logTextBox
                            wrapMode: Text.WordWrap
                            readOnly: true
                            text: ""
                            width: parent.width
                        }
                    }

                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Button
                        {
                            text: "Verbindungstest"
                            Layout.fillWidth: true
                            onClicked: getServerConnection();
                        }

                        Button
                        {
                            text: "Schließen"
                            Layout.fillWidth: true
                            onClicked: settingDialog.close()
                        }
                    }
                }
            }
        }
    }

    // Button Logfensters
    QfToolButton
    {
        id: logButton
        bgcolor: Theme.darkGray
        iconSource: "ressource/plSettings.svg"
        iconColor: "white"
        round: true
        onClicked:
        {
            //mainWindow.displayToast("logButton wurde geklickt")

            getSettings()
            settingDialog.open()
        }
    }

    // Button Sync
    QfToolButton
    {
        id: syncButton
        bgcolor: Theme.darkGray
        iconSource: 'ressource/plSync.svg'
        iconColor: "white"
        round: true
        onClicked:
        {
            syncData()
        }
    }

// ###################################################### FUNCTIONS ###################################################### //

    // Serververbindung anfragen (Testen)
    function getServerConnection()
    {
        var serverAdress = settings.value("serveradress", "");
        Logic.serverAvailable(serverAdress);
    }

    // Speicherung vom "Ersten"-Einstellungsmenü
    function saveBasicSettings()
    {
        var serverAdress = firstServerAdr.text;
        var apitoken = firstApiToken.text;

        if (serverAdress && apitoken)
        {
            settings.setValue("serveradress", serverAdress);
            settings.setValue("token", apitoken);
            settings.sync();
            firstSettingDialog.close();
            mainWindow.displayToast("Einstellungen wurden gespeichert!");
        }
        else
        {
            mainWindow.displayToast("Speichern fehlgeschlagen, alle Felder müssen ausgefüllt sein!");
        }
    }

    // Speicherung des Einstellungsmenü
    function saveSettings()
    {
        var serverName = serverField.text;
        var username = comboBox.currentText;
        var apitoken = apiTokenField.text;

        if (serverName && apitoken)
        {
            settings.setValue("serveradress", serverName);
            settings.setValue("username", username);
            settings.setValue("token", apitoken);
            settings.sync();
            settingDialog.close();
            mainWindow.displayToast("Einstellungen wurden gespeichert!");
        }
        else
        {
            mainWindow.displayToast("Speichern fehlgeschlagen, alle Felder müssen ausgefüllt sein!");
        }
    }

    // Ruft & setzt die Daten vom Einstellungsmenü auf
    function getSettings()
    {
        serverField.text = settings.value("serveradress", "");
        apiTokenField.text = settings.value("token", "");
        lastEditDateField.text = settings.value("lasteditdate", "");

        // gespeicherten User wieder in ComboBox setzen
        var savedUser = settings.value("username", "");
        for (var i = 0; i < comboBox.count; i++)
        {
            var item = comboBox.model.get(i);
            if (item.key === savedUser)
            {
                comboBox.currentIndex = i;
                break;
            }
        }
        settings.sync();
    }

    // Ruft alle Benutzer ab, die gültig sind
    function getSyncUser()
    {
        var serverAdress = settings.value("serveradress", "");
        var newAdress = serverAdress + "DesktopModules/SWSTQFieldWS/API/QFieldUser/";

        var httpRequest = new XMLHttpRequest();
        httpRequest.open("GET", newAdress, true);
        httpRequest.timeout = 15000;

        httpRequest.onreadystatechange = function()
        {
            if (httpRequest.readyState === XMLHttpRequest.DONE)
            {
                if (httpRequest.status === 200)
                {
                    var response = JSON.parse(httpRequest.responseText);

                    userModel.clear(); // Optional: altes Model leeren

                    for (var i = 0; i < response.length; i++)
                    {
                        userModel.append({
                            key: response[i].UserName,
                            value: response[i].UserID,
                            quelle: response[i].Quelle,
                            display: response[i].UserName + " (" + response[i].Quelle + ")"
                        });
                    }

                    mainWindow.displayToast("Monteure wurden synchronisiert...");

                    // Benutzer automatisch auswählen
                    var savedUser = settings.value("username", "");
                    for (var j = 0; j < userModel.count; j++)
                    {
                        var item = userModel.get(j);
                        if (item.display === savedUser)
                        {
                            comboBox.currentIndex = j;
                            settings.setValue("quelle", item.quelle);
                            settings.sync();
                            break;
                        }
                    }

                }
                else
                {
                    Logic.logToGui("Server: " + newAdress, 2);
                    Logic.logToGui("Monteur-Synchronisierung fehlgeschlagen: " + httpRequest.status, 3);
                    Logic.logToGui("Fehler: " + httpRequest.statusText, 3);
                }
            }
        };

        httpRequest.send();
    }

    // Verarbeitet alle Daten die vom Sever als "Antwort" zurückkamen (+ Userdaten)
    function applyServerUpdates(syncdate, records)
    {
        var layerList = ["Hydrant_VN", "Hydrant_TN", "Hydrant_AN"];
        var updateData = false;

        for (var i = 0; i < layerList.length; i++)
        {
            var layers = qgisProject.mapLayersByName(layerList[i]);
            var layer = layers.length > 0 ? layers[0] : null;

            if (!layer)
            {
                Logic.logToGui("Layer " + layer + " nicht gefunden!", 3);
                return;
            }

            var id = 1;
            while (true)
            {
                const myObject = layer.getFeature(id);

                const breakCheck = myObject.attribute("G3E_FID");
                if (!breakCheck)
                {
                    Logic.logToGui("Alle lokalen Objekte wurden überprüft. ID zuletzt: " + id, 2);
                    break;
                }

                const localFID = myObject.attribute("G3E_FID");

                var matchingRecord = null;
                for (var y = 0; y < records.length; y++)
                {
                    const serverFID = String(records[y].FID).trim();
                    const localFIDStr = String(localFID).trim();

                    if (serverFID === localFIDStr)
                    {
                        //Logic.logToGui("Item wurde gefunden: " + localFID, 1);
                        matchingRecord = records[y];
                        break;
                    }
                }

                if (matchingRecord)
                {
                    const featureId = myObject.id;

                    layer.changeAttributeValue(featureId, layer.fields.indexOf("Status"), matchingRecord.StateText);
                    layer.changeAttributeValue(featureId, layer.fields.indexOf("ServiceDate"), matchingRecord.ServiceDate);
                    layer.changeAttributeValue(featureId, layer.fields.indexOf("Gaengigkeit"), matchingRecord.Gaengigkeit);
                    layer.changeAttributeValue(featureId, layer.fields.indexOf("Beschilderung"), matchingRecord.Beschilderung);
                    layer.changeAttributeValue(featureId, layer.fields.indexOf("Entleerung"), matchingRecord.Entleerung);
                    layer.changeAttributeValue(featureId, layer.fields.indexOf("Bemerkung"), matchingRecord.Bemerkung);
                    layer.changeAttributeValue(featureId, layer.fields.indexOf("Zustand"), matchingRecord.Zustand);
                    layer.changeAttributeValue(featureId, layer.fields.indexOf("Bearbeiter"), matchingRecord.Bearbeiter);
                    layer.changeAttributeValue(featureId, layer.fields.indexOf("Gespuelte_Menge"), matchingRecord.Gespuelte_Menge);

                    //Logic.logToGui("Objekt mit FID " + localFID + " aktualisiert.", 1);
                    updateData = true;
                }

                id++;
            }

            if (!layer.commitChanges())
            {
                Logic.logToGui("Fehler beim Speichern der Änderungen.", 3);
            }
        }

        // TODO: SYNCDATA OHNE FUNKTION GEGENCHECK MIT LOG-DEBUG
        if(updateData)
        {
            settings.setValue("lasteditdate", Logic.getTimeStamp(syncdate));
            settings.sync();
        }

        Logic.logToGui("Synchronisierung abgeschlossen.", 2);
        mainWindow.displayToast("Synchronisierung abgeschlossen.")
    }

    // Synchronisation
    function syncData()
    {
        var userCheck = comboBox.currentValue === undefined ? null : comboBox.currentValue;

        if(userCheck !== null)
        {
            mainWindow.displayToast("Synchronisierung wird ausgeführt...")
            Logic.logToGui("Synchronisierung gestartet.", 2);

            var userid = userCheck;
            var apitoken = settings.value("token", "");

            // ####### Abruf der Schicht ####### //
            var layerList = ["Hydrant_VN", "Hydrant_TN", "Hydrant_AN"];
            var records = [];
            for (var i = 0; i < layerList.length; i++)
            {
                var layers = qgisProject.mapLayersByName(layerList[i]);
                var layer = layers.length > 0 ? layers[0] : null;

                if (!layer)
                {
                    Logic.logToGui("Layer "+ layerList[i] +" wurde nicht gefunden!", 3);
                    continue;
                }

                if (!layer.isEditable)
                {
                    layer.startEditing(); // Beginne Editiersitzung
                }

                var fieldNames = layer.fields.names;

                // ####### Abruf der Details ####### //
                var id = 1;
                var maxID = 5;

                while (true)
                {
                    var changeItemValue = "false";
                    var fidValue, district, statusValue, serviceDateValue, Gaengigkeit, Beschilderung, Entleerung, Bemerkung, Zustand, Bearbeiter, Gespuelte_Menge;
                    const myObject = layer.getFeature(id);

                    const breakCheck = myObject.attribute("G3E_FID");
                    if (!breakCheck)
                    {
                        Logic.logToGui("Alle verfügbaren Objekte gefunden... (" + id + ")", 2);
                        break;
                    }

                    const filter = myObject.attribute("Status");
                    if (filter !== undefined)
                    {
                        const isEdit = myObject.attribute("Editieren");

                        // Wenn bearbeitet
                        if (isEdit === "bearbeitet")
                        {
                            myObject.setAttribute("ServiceDate", new Date());
                            myObject.setAttribute("changeItem", "true");

                            // TODO: Maik nachfragen bzgl. ob jeder Vorgang ein Service ist.

                            // Daten aus den Feldern
                            fidValue = myObject.attribute("G3E_FID");
                            district = myObject.attribute("District");
                            statusValue = myObject.attribute("Status");
                            serviceDateValue = myObject.attribute("ServiceDate");
                            changeItemValue = myObject.attribute("changeItem");
                            Gaengigkeit = myObject.attribute("Gaengigkeit");
                            Beschilderung = myObject.attribute("Beschilderung");
                            Entleerung = myObject.attribute("Entleerung");
                            Bemerkung = myObject.attribute("Bemerkung");
                            Zustand = myObject.attribute("Zustand");
                            Bearbeiter = settings.value("quelle", "");
                            Gespuelte_Menge = myObject.attribute("Gespuelte_Menge");
                        }

                        if(changeItemValue === "true")
                        {
                            // Record in JSON pushen
                            records.push
                            ({
                              FID: fidValue,
                              District: district,
                              ChangeUser: userid,
                              StateText: statusValue,
                              ServiceDate: serviceDateValue,
                              Gaengigkeit: Gaengigkeit,
                              Beschilderung: Beschilderung,
                              Entleerung: Entleerung,
                              Bemerkung: Bemerkung,
                              Zustand: Zustand,
                              Bearbeiter: Bearbeiter,
                              Gespuelte_Menge: Gespuelte_Menge,
                            });

                        }

                        // Attribute in QGIS-Karte ändern
                        var fieldIndex = layer.fields.indexOf("Editieren");
                        var fieldIndex2 = layer.fields.indexOf("Bearbeiter");
                        var featureId = myObject.id;

                        if (fieldIndex !== -1 && isEdit === "bearbeitet")
                        {
                            var success = layer.changeAttributeValue(featureId, fieldIndex, "unbearbeitet");
                            if (!success)
                            {
                                Logic.logToGui("Fehler beim Setzen von Edit-Mode für Feature-ID " + featureId, 3);
                            } else
                            {
                                Logic.logToGui("Edit-Mode auf 'unbearbeitet' gesetzt für Feature-ID " + featureId, 1);
                            }

                            var success2 = layer.changeAttributeValue(featureId, fieldIndex2, Bearbeiter);
                            if (!success2)
                            {
                                Logic.logToGui("Fehler beim Setzen der Quelle für Feature-ID " + featureId, 3);
                            } else
                            {
                                Logic.logToGui("Quelle auf " + Bearbeiter + " gesetzt für Feature-ID " + featureId, 1);
                            }
                        }
                    }

                    id++;
                }
            }

            // ####### Metadaten speichern und übertragen ####### //
            var basicDate = settings.value("lasteditdate", "") || null;
            var formDate = Logic.toIsoDateTime(basicDate);

            var basicDataList =
            {
                UserID: userid,
                SyncDate: formDate,
                Records: records
            };

            var serverAdress = settings.value("serveradress", "");
            var jsonString = JSON.stringify(basicDataList);

            Logic.logToGui("Daten wurden gespeichert...", 2);
            Logic.logToGui(jsonString, 1);

            // Senden an Server
            Logic.connectData(serverAdress, apitoken, jsonString);
        }
        else
        {
            mainWindow.displayToast("Synchronisierung fehlgeschlagen... (siehe. Log)")
            Logic.logToGui("Monteur konnte nicht gefunden werden!", 3);
        }
    }
}
