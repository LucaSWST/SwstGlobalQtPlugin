// Ablauf zum setzen eines Loggers #LOG#
var logCallback = null;

function setLogCallback(callback)
{
    logCallback = callback;
}

function logToGui(message, status)
{
    if (logCallback)
    {
        logCallback(setLogText(message, status));
    }
}

function setLogText(message, status)
{
    if(typeof status == "number")
    {
        switch(status)
        {
        case 1:
            return getTimestamp() + " - [INFO] " + message;
        case 2:
            return getTimestamp() + " - [WARNING] " + message;
        case 3:
            return getTimestamp() + " - [ERROR] " + message;
        default:
            return getTimestamp() + " - [UNKNOWN] " + message;
        }
    }
    else
    {
        return getTimestamp() + " - [ERROR] Fehler bei der Logausgabe aufgetreten!";
    }
}

function getTimestamp()
{
    var date = new Date();

    return date.toLocaleDateString("de-DE")
}

function convertOnceDateFormat(str)
{
    var d = new Date(str);
    if (isNaN(d.getTime())) return null; // ungültiges Datum -> null zurück

    return d.toLocaleDateString("de-DE");
}

function serverAvailable()
{
    // Create a http httpRequest
    var httpRequest = new XMLHttpRequest();
    var serverAdress = "https://vmdev2.swst.de/SWSTQFieldBackend/Process.aspx";

    // Open the Connection to the Server
    httpRequest.open("POST", serverAdress, true);
    httpRequest.timeout = 5000;

    httpRequest.setRequestHeader("Content-Type", "application/json");

    logToGui("Server: " + serverAdress, 1);
    logToGui("Verbindung zum Server wird hergestellt...", 1);

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === httpRequest.DONE)
        {
            if (httpRequest.status === 405)
            {
                logToGui("Serververbindung erfolgreich!", 1);
                logToGui("Status: " + httpRequest.status + " " + httpRequest.statusText, 1);
            } else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.statusText, 1);
            }
        }
    };

    httpRequest.send();

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
    };
}

function connectData(serverAdress, jsonString)
{
    var newAdress = serverAdress + "?MethodName=SyncData";

    // Create a http httpRequest
    var httpRequest = new XMLHttpRequest();

    httpRequest.open("POST", newAdress, true);
    httpRequest.timeout = 5000;

    httpRequest.setRequestHeader("Content-Type", "application/json");

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === XMLHttpRequest.DONE)
        {
            if (httpRequest.status >= 200 && httpRequest.status <= 405)
            {
                logToGui("Verbindung erfolgreich hergestellt!", 1);
                logToGui("Status: " + httpRequest.status + " " + httpRequest.statusText, 1);
                logToGui("Antwort: " + httpRequest.responseText, 1);

                var response = JSON.parse(httpRequest.responseText);
                var records = response.Records;

                applyServerUpdates(records);
            }

            else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.statusText, 1);
            }
        }
    };

    httpRequest.send(jsonString);

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
    };
}



