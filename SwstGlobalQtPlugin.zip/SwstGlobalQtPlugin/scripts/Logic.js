// Ablauf zum setzen eines Loggers #LOG#
var logCallback = null;

function setLogCallback(callback)
{
    logCallback = callback;
}

function logToGui(message, status)
{
    if (logCallback)
    {
        logCallback(setLogText(message, status));
    }
}

function setLogText(message, status)
{
    if(typeof status == "number")
    {
        switch(status)
        {
        case 1:
            return getLogStamp() + " - [INFO] " + message;
        case 2:
            return getLogStamp() + " - [WARNING] " + message;
        case 3:
            return getLogStamp() + " - [ERROR] " + message;
        default:
            return getLogStamp() + " - [UNKNOWN] " + message;
        }
    }
    else
    {
        return getLogStamp() + " - [ERROR] Fehler bei der Logausgabe aufgetreten!";
    }
}

function getLogStamp()
{
    var date = new Date();

    return date.toLocaleDateString("de-DE")
}

function getTimeStamp(str)
{
    var d = new Date(str);
    if (isNaN(d.getTime())) return null; // ungültiges Datum -> null zurück

    return d.toLocaleString("de-DE");
}

function toIsoDateTime(str) // ISO-Format (Übergabe ggf. Online-Quelle)
{
  if (!str || typeof str !== 'string') return null;
  // ⛔ Wenn kein String übergeben wurde oder leer ist → abbrechen

  str = str.trim();
  // 🧹 Entfernt Leerzeichen am Anfang/Ende des Strings

  // ✅ Fall 2: Deutsches Format mit Uhrzeit → z. B. "15.10.23 14:30:26"
  if (str.includes(' '))
  {
    const [d, t] = str.split(' ');
    // Teilt Datum & Uhrzeit: ["15.10.23", "14:30:26"]

    let [day, month, year] = d.split('.').map(Number);
    // Extrahiert Tag, Monat, Jahr → [15, 10, 23]

    if (year < 100) year += 2000;
    // 🔁 Macht aus "23" → "2023"

    const [h, m, s = 0] = t.split(':').map(Number);
    // Extrahiert Stunde & Minute → [14, 30]

    // Baut ISO-Format zusammen
    return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}T${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
}

function toIsoDate(str)
{
  if (!str || typeof str !== 'string') return null;
  return str.trim().slice(0, 10);
}

function serverAvailable()
{
    // Create a http httpRequest
    var httpRequest = new XMLHttpRequest();
    var serverAdress = "https://vmdev2.swst.de/DNNDEV/";

    // Open the Connection to the Server
    httpRequest.open("GET", serverAdress, true);
    httpRequest.timeout = 15000;

    httpRequest.setRequestHeader("Content-Type", "application/json");

    logToGui("Server: " + serverAdress, 1);
    logToGui("Verbindung zum Server wird hergestellt...", 1);

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === httpRequest.DONE)
        {
            if (httpRequest.status === 200)
            {
                logToGui("Serververbindung erfolgreich!", 1);
            } else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.statusText, 1);
            }
        }
    };

    httpRequest.send();

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
    };
}

function connectData(serverAdress, token, jsonString)
{
    var newAdress = serverAdress + "QFieldDataRecord/";

    // Create a http httpRequest
    var httpRequest = new XMLHttpRequest();

    httpRequest.open("POST", newAdress, true);
    httpRequest.timeout = 15000;

    httpRequest.setRequestHeader("Content-Type", "application/json");
    httpRequest.setRequestHeader("Authorization", "Bearer " + token);

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === XMLHttpRequest.DONE)
        {
            if (httpRequest.status === 200)
            {
                logToGui("Verbindung erfolgreich hergestellt!", 1);
                logToGui("Status: " + httpRequest.status + " " + httpRequest.statusText, 1);
                logToGui("Antwort: " + httpRequest.responseText, 1);

                var response = JSON.parse(httpRequest.responseText);
                var syncdate = response.SyncDate;
                var records = response.Records;

                applyServerUpdates(syncdate, records);
            }

            else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.statusText, 1);
            }
        }
    };

    httpRequest.send(jsonString);

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
    };
}



