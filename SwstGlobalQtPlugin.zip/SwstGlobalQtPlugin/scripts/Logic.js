// Ablauf zum setzen eines Loggers #LOG#
var logCallback = null;

function setLogCallback(callback)
{
    logCallback = callback;
}

function logToGui(message, status)
{
    if (logCallback)
    {
        logCallback(setLogText(message, status));
    }
}

function setLogText(message, status)
{
    if(typeof status == "number")
    {
        switch(status)
        {
        case 1:
            return getTimestamp() + " - [INFO] " + message;
        case 2:
            return getTimestamp() + " - [WARNING] " + message;
        case 3:
            return getTimestamp() + " - [ERROR] " + message;
        default:
            return getTimestamp() + " - [UNKNOWN] " + message;
        }
    }
    else
    {
        return getTimestamp() + " - [ERROR] Fehler bei der Logausgabe aufgetreten!";
    }
}

function getTimestamp()
{
    var date = new Date();

    return date.toLocaleDateString("de-DE")
}

function convertOnceDateFormat(str)
{
    var d = new Date(str);
    if (isNaN(d)) return null; // ungültiges Datum -> null zurück

    return d.toLocaleDateString("de-DE");
}

// Ablauf zur herstellung einer Serververbindung #CONNECTION#

// Variables for Connection

function serverConnection(serverAdress, jsonString)
{
    // Create a http httpRequest
    var httpRequest = new XMLHttpRequest();

    // Open the Connection to the Server
    httpRequest.open("POST", serverAdress, true); // TODO: Möglicherweise neuen Settingbereich für Http Einstellungen
    httpRequest.timeout = 5000;

    logToGui("Server: " + serverAdress, 1);
    logToGui("Verbindung zum Server wird hergestellt...", 1);

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === XMLHttpRequest.DONE)
        {
            if (httpRequest.status >= 200 && httpRequest.status <= 405)
            {
                logToGui("Verbindung erfolgreich hergestellt!", 1);
                logToGui("Status: " + httpRequest.status + " " + httpRequest.statusText, 1);
                logToGui("Antwort: " + httpRequest.responseText, 1);
            } else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.responseText, 1);
            }
        }
    };

    httpRequest.send(jsonString);

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
    };
}



