import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.qfield // Fehler bei QT-Creator (Module nicht in QT-C integriert)
import org.qgis // Fehler bei QT-Creator (Module nicht in QT-C integriert)
import Theme // Fehler bei QT-Creator (Module nicht in QT-C integriert)

import "qrc:/qml" as QFieldItems

// Import JS-Datein
import "scripts/Logic.js" as Logic

// QML-JS Content mit: "setContextProperty, qmlRegisterType, qmlRegisterSingletonType"

Item
{
    id: plugin

    // Zugriff auf QField-API
    property var mainWindow: iface.mainWindow()

    Component.onCompleted:
    {
        mainWindow.displayToast("SwstGlobalQtPlugin geladen...")
        iface.addItemToPluginsToolbar(logButton)
        iface.addItemToPluginsToolbar(syncButton)

        // User abrufen
        getSyncUser()

        var checkServerAdress = settings.value("serveradress", "").toString();
        var checkToken = settings.value("token", "").toString();

        if(!checkServerAdress || !checkToken)
        {
            firstSettingDialog.open()
        }

        Logic.setLogCallback(function refreshGUI(msg)
        {
            logTextBox.append(msg)
        })
    }

    // firstAppStart Menü (Grundeinstellung)
    Dialog
    {
        id: firstSettingDialog
        parent: mainWindow.contentItem

        title: "Grundeinstellungen"
        visible: false
        modal: true
        font: Theme.defaultFont

        z: 10000
        width: 430
        height: 330
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2

        ColumnLayout
        {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 15

            // Server
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "Server:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstServerAdr
                    Layout.fillWidth: true
                    placeholderText: "Adresse eingeben"
                }
            }

            // Token
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "Token:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstApiToken
                    Layout.fillWidth: true
                    placeholderText: "Token eingeben"
                }
            }

            // Buttons zentriert
            RowLayout
            {
                Layout.alignment: Qt.AlignHCenter
                spacing: 20

                Button
                {
                    text: "Abbrechen"
                    onClicked: firstSettingDialog.close()
                }

                Button
                {
                    text: "Speichern"
                    onClicked:
                    {
                        saveBasicSettings();
                    }
                }
            }
        }
    }

    // Einstellungs Menü
    Dialog
    {
        id: settingDialog
        parent: mainWindow.contentItem

        title: "Einstellungen & Log"
        visible: false
        modal: true
        font: Theme.defaultFont

        z: 10000
        width: 390
        height: 440
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2

        ScrollView
        {
            anchors.fill: parent
            contentWidth: parent.width
            contentHeight: columnContent.height

            ColumnLayout
            {
                id: columnContent
                width: parent.width
                spacing: 20
                anchors.margins: 20

                // ================= Settings Bereich =================
                ColumnLayout
                {
                    Layout.fillWidth: true
                    spacing: 10

                    Label { text: "Einstellungen"; font.bold: true; font.pointSize: 14 }
                    Rectangle { height: 1; color: "#888"; Layout.fillWidth: true }

                    // Server
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Server:"; Layout.preferredWidth: 80 }
                        TextField { id: serverField; Layout.fillWidth: true; placeholderText: "Adresse eingeben" }
                    }

                    // Token
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Token:"; Layout.preferredWidth: 80 }
                        TextField { id: apiTokenField; Layout.fillWidth: true; placeholderText: "Token eingeben" }
                    }

                    // Monteur
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Monteur:"; Layout.preferredWidth: 80 }

                        ComboBox
                        {
                            id: comboBox
                            Layout.fillWidth: true
                            textRole: "key"
                            valueRole: "value"

                            model: userModel

                            ListModel
                            {
                                id: userModel
                            }
                        }
                    }

                    // lastEditDateField
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Letzte\nÄnderung:"; wrapMode: Text.WordWrap; Layout.preferredWidth: 80 }
                        TextField { id: lastEditDateField; Layout.fillWidth: true; placeholderText: "Letzte Änderung"; readOnly: true }
                    }

                    // Buttons Settings
                    RowLayout
                    {
                        Layout.alignment: Qt.AlignHCenter
                        spacing: 20

                        Button
                        {
                            text: "Abbrechen"
                            onClicked: settingDialog.close()
                        }

                        Button
                        {
                            text: "Speichern"
                            onClicked:
                            {
                                saveSettings();
                            }
                        }
                    }
                }

                // ================= Log Bereich =================
                ColumnLayout
                {
                    Layout.fillWidth: true
                    spacing: 10

                    Label { text: "Log"; font.bold: true; font.pointSize: 14 }
                    Rectangle { height: 1; color: "#888"; Layout.fillWidth: true }

                    ScrollView
                    {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 200

                        TextArea
                        {
                            id: logTextBox
                            wrapMode: Text.WordWrap
                            readOnly: true
                            text: ""
                            width: parent.width
                        }
                    }

                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Button
                        {
                            text: "Verbindungstest"
                            Layout.fillWidth: true
                            onClicked: Logic.serverAvailable();
                        }

                        Button
                        {
                            text: "Schließen"
                            Layout.fillWidth: true
                            onClicked: settingDialog.close()
                        }
                    }
                }
            }
        }
    }

    // Button Logfensters
    QfToolButton
    {
        id: logButton
        bgcolor: Theme.darkGray
        iconSource: "ressource/plSettings.svg"
        iconColor: "white"
        round: true
        onClicked:
        {
            //mainWindow.displayToast("logButton wurde geklickt")

            getSettings()
            settingDialog.open()
        }
    }

    // Button Sync
    QfToolButton
    {
        id: syncButton
        bgcolor: Theme.darkGray
        iconSource: 'ressource/plSync.svg'
        iconColor: "white"
        round: true
        onClicked:
        {
            syncData()
        }
    }

// ###################################################### FUNCTIONS ###################################################### //

    function saveBasicSettings()
    {
        var serverAdress = firstServerAdr.text;
        var apitoken = firstApiToken.text;

        if (serverAdress && apitoken)
        {
            settings.setValue("serveradress", serverAdress);
            settings.setValue("token", apitoken);
            settings.sync();
            firstSettingDialog.close();
            mainWindow.displayToast("Einstellungen wurden gespeichert!");
        }
        else
        {
            mainWindow.displayToast("Speichern fehlgeschlagen, alle Felder müssen ausgefüllt sein!");
        }
    }

    function saveSettings()
    {
        var serverName = serverField.text;
        var username = comboBox.currentText;
        var apitoken = apiTokenField.text;

        if (serverName && apitoken)
        {
            settings.setValue("serveradress", serverName);
            settings.setValue("username", username);
            settings.setValue("token", apitoken);
            settings.sync();
            settingDialog.close();
            mainWindow.displayToast("Einstellungen wurden gespeichert!");
        }
        else
        {
            mainWindow.displayToast("Speichern fehlgeschlagen, alle Felder müssen ausgefüllt sein!");
        }
    }

    function getSettings()
    {
        serverField.text = settings.value("serveradress", "");
        apiTokenField.text = settings.value("token", "");
        lastEditDateField.text = settings.value("lasteditdate", "");

        // gespeicherten User wieder in ComboBox setzen
        var savedUser = settings.value("username", "");
        for (var i = 0; i < comboBox.count; i++)
        {
            var item = comboBox.model.get(i);
            if (item.key === savedUser)
            {
                comboBox.currentIndex = i;
                break;
            }
        }
        settings.sync();
    }

    function getSyncUser()
    {
        var serverAdress = settings.value("serveradress", "");
        var newAdress = serverAdress + "QFieldUser/";

        var httpRequest = new XMLHttpRequest();
        httpRequest.open("GET", newAdress, true);
        httpRequest.timeout = 15000;

        httpRequest.onreadystatechange = function()
        {
            if (httpRequest.readyState === XMLHttpRequest.DONE)
            {
                if (httpRequest.status >= 200 && httpRequest.status <= 405)
                {
                    var response = JSON.parse(httpRequest.responseText);

                    userModel.clear(); // Optional: altes Model leeren

                    for (var i = 0; i < response.length; i++)
                    {
                        userModel.append({
                            key: response[i].UserName,
                            value: response[i].UserID
                        });
                    }

                    mainWindow.displayToast("Monteure wurden synchronisiert...");

                    // === Benutzer automatisch auswählen ===
                    var savedUser = settings.value("username", "");
                    for (var j = 0; j < userModel.count; j++) {
                        var item = userModel.get(j);
                        if (item.key === savedUser) {
                            comboBox.currentIndex = j;
                            break;
                        }
                    }

                }
                else
                {
                    Logic.logToGui("Server: " + newAdress, 2);
                    Logic.logToGui("Monteur-Synchronisierung fehlgeschlagen: " + httpRequest.status, 3);
                    Logic.logToGui("Fehler: " + httpRequest.statusText, 3);
                }
            }
        };

        httpRequest.send();
    }

    function applyServerUpdates(records)
    {
        const layers = qgisProject.mapLayersByName("Hydrant_VN");
        const layer = layers.length > 0 ? layers[0] : null;

        if (!layer)
        {
            Logic.logToGui("Layer 'Hydrant_VN' nicht gefunden!", 3);
            return;
        }

        var id = 1;
        while (true)
        {
            const myObject = layer.getFeature(id);

            const breakCheck = myObject.attribute("G3E_FID");
            if (!breakCheck)
            {
                Logic.logToGui("Alle lokalen Objekte wurden überprüft. ID zuletzt: " + id, 2);
                break;
            }

            const localFID = myObject.attribute("G3E_FID");

            var matchingRecord = null;
            for (var i = 0; i < records.length; i++)
            {
                const serverFID = String(records[i].FID).trim();
                const localFIDStr = String(localFID).trim();

                if (serverFID === localFIDStr && records[i].changeItem === true)
                {
                    //Logic.logToGui("Item wurde gefunden: " + localFID, 1);
                    matchingRecord = records[i];
                    break;
                }
            }

            if (matchingRecord)
            {
                const featureId = myObject.id;
                const changedateConvert  = Logic.toIsoDateTime(matchingRecord.ChangeDate);

                layer.changeAttributeValue(featureId, layer.fields.indexOf("BEZEICHNUN"), matchingRecord.Bezeichnung);
                layer.changeAttributeValue(featureId, layer.fields.indexOf("LAGE_ZUM_S"), matchingRecord.Lage_Zum_S);
                layer.changeAttributeValue(featureId, layer.fields.indexOf("Status"), matchingRecord.StateText);
                layer.changeAttributeValue(featureId, layer.fields.indexOf("ChangeDate"), changedateConvert);

                //Logic.logToGui("Objekt mit FID " + localFID + " aktualisiert.", 1);
            }

            id++;
        }

        var userDate = settings.value("lasteditdate", "");
        if(!userDate)
        {
            settings.setValue("lasteditdate", Logic.getTimeStamp(new Date()));
            settings.sync();
        }

        if (!layer.commitChanges())
        {
            Logic.logToGui("Fehler beim Speichern der Änderungen.", 3);
        }

        Logic.logToGui("Synchronisierung abgeschlossen.", 2);
        mainWindow.displayToast("Synchronisierung abgeschlossen.")
    }

    function syncData()
    {
        var username = settings.value("username", "");

        if(username)
        {
            mainWindow.displayToast("Synchronisierung wird ausgeführt...")
            Logic.logToGui("Synchronisierung gestartet.", 2);

            // Projekt/Grunddaten abrufen
            //var directory = qgisProject.fileName;
            //var path = directory.split("/");
            //var projectName = path[path.length - 1];
            var userid = comboBox.currentValue;
            var user = username;
            var apitoken = settings.value("token", "");

            // ####### Abruf der Schicht ####### //
            var layers = qgisProject.mapLayersByName("Hydrant_VN"); // TODO: Evtl. für alle Layers auto. abrufen.
            var layer = layers.length > 0 ? layers[0] : null;

            if (!layer)
            {
                Logic.logToGui("Layer 'Hydrant_VN' wurde nicht gefunden!", 3);
                return;
            }

            if (!layer.isEditable)
            {
                layer.startEditing(); // Beginne Editiersitzung
            }

            var fieldNames = layer.fields.names;

            // ####### Abruf der Details ####### //
            var records = [];
            var id = 1;
            var maxID = 5;

            while (true)
            {
                const myObject = layer.getFeature(id);

                const breakCheck = myObject.attribute("G3E_FID");
                if (!breakCheck)
                {
                    Logic.logToGui("Alle verfügbaren Objekte gefunden... (" + id + ")", 2);
                    break;
                }

                const filter = myObject.attribute("Status");
                if (filter !== undefined)
                {
                    const isEdit = myObject.attribute("Editieren");

                    // Daten aus den Feldern
                    var fidValue = myObject.attribute("G3E_FID");
                    var bezeichnungValue = myObject.attribute("BEZEICHNUN");
                    var lage_zum_sValue = myObject.attribute("LAGE_ZUM_S");
                    var statusValue = myObject.attribute("Status");
                    var dateValue = Logic.getTimeStamp(myObject.attribute("ServiceDate"));
                    var changeItemValue = myObject.attribute("changeItem");

                    // Wenn heute bearbeitet wurde
                    if (dateValue === Logic.getTimeStamp(new Date()) && isEdit === "bearbeitet")
                    {
                        myObject.setAttribute("changeItem", "true");
                        changeItemValue = myObject.attribute("changeItem");

                        settings.setValue("lasteditdate", Logic.getTimeStamp(new Date()));
                        settings.sync();
                    }

                    if(changeItemValue === "true")
                    {
                        // Record in JSON pushen
                        records.push
                        ({
                            fid: fidValue,
                            bezeichnung: bezeichnungValue,
                            lage_zum_s: lage_zum_sValue,
                            changeuser: userid,
                            servicedate: dateValue,
                            statetext: statusValue,
                            changeitem: changeItemValue
                        });
                    }

                    // ##### Attribut "checkEdit" auf "unbearbeitet" setzen, wenn "bearbeitet" war #####
                    var fieldIndex = layer.fields.indexOf("Editieren");
                    var featureId = myObject.id;

                    if (fieldIndex !== -1 && isEdit === "bearbeitet")
                    {
                        var success = layer.changeAttributeValue(featureId, fieldIndex, "unbearbeitet");
                        if (!success)
                        {
                            Logic.logToGui("Fehler beim Setzen von Edit-Mode für Feature-ID " + featureId, 3);
                        } else
                        {
                            Logic.logToGui("Edit-Mode auf 'unbearbeitet' gesetzt für Feature-ID " + featureId, 1);
                        }
                    }
                }

                id++;
            }

            // ####### Metadaten speichern und übertragen ####### //
            var basicDate = settings.value("lasteditdate", "") || null;

            var basicDataList =
            {
                UserID: userid,
                UserName: user,
                SyncDate: basicDate,
                Records: records
            };

            var serverAdress = settings.value("serveradress", "");
            var jsonString = JSON.stringify(basicDataList);

            Logic.logToGui("Daten wurden gespeichert...", 2);
            //Logic.logToGui(jsonString, 1);

            // Senden an Server
            Logic.connectData(serverAdress, apitoken, jsonString);
        }
        else
        {
            mainWindow.displayToast("Synchronisierung fehlgeschlagen... (siehe. Log)")
            Logic.logToGui("Synchronisierung Fehlgeschlagen...", 3);
        }
    }
}
