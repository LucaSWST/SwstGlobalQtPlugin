import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

import org.qfield // Fehler bei QT-Creator (Module nicht in QT-C integriert)
import org.qgis // Fehler bei QT-Creator (Module nicht in QT-C integriert)
import Theme // Fehler bei QT-Creator (Module nicht in QT-C integriert)

import "qrc:/qml" as QFieldItems

// Import JS-Datein
import "scripts/Logic.js" as Logic

// QML-JS Content mit: "setContextProperty, qmlRegisterType, qmlRegisterSingletonType"

Item
{
    id: plugin

    // Variables
    property string logText: ""
    signal logMessage(string message)

    // Zugriff auf QField-API
    property var mainWindow: iface.mainWindow()

    Component.onCompleted:
    {
        mainWindow.displayToast("SwstGlobalQtPlugin geladen...")
        iface.addItemToPluginsToolbar(logButton)
        iface.addItemToPluginsToolbar(exportButton)
        //iface.addItemToPluginsToolbar(importButton)

        var checkUsername = settings.value("username", "").toString();
        var checkApiToken = settings.value("apitoken", "").toString();

        if(!checkUsername || !checkApiToken)
        {
            firstSettingDialog.open()
        }

        Logic.setLogCallback(function refreshGUI(msg)
        {
            logTextBox.append(msg)
        })
    }

    // firstAppStart Menü (Grundeinstellung)
    Dialog
    {
        id: firstSettingDialog
        parent: mainWindow.contentItem

        title: "Grundeinstellungen"
        visible: false
        modal: true
        font: Theme.defaultFont

        z: 10000
        width: 430
        height: 330
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2

        ColumnLayout
        {
            anchors.fill: parent
            anchors.margins: 20
            spacing: 15

            // Name
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "Name:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstNameField
                    Layout.fillWidth: true
                    placeholderText: "Montuer-Name eingeben"
                }
            }

            // Token 1
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "ApiToken:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstApiTkField
                    Layout.fillWidth: true
                    placeholderText: "ApiToken eingeben"
                }
            }

            // Token 2
            RowLayout
            {
                Layout.fillWidth: true
                spacing: 10

                Label
                {
                    text: "SyncDate:"
                    Layout.preferredWidth: 80
                }

                TextField
                {
                    id: firstLastEditDateField
                    Layout.fillWidth: true
                    placeholderText: "Letzte Änderung"
                    readOnly: true
                }
            }

            // Buttons zentriert
            RowLayout
            {
                Layout.alignment: Qt.AlignHCenter
                spacing: 20

                Button
                {
                    text: "Abbrechen"
                    onClicked: firstSettingDialog.close()
                }

                Button
                {
                    text: "Speichern"
                    onClicked:
                    {
                        saveBasicSettings();
                    }
                }
            }
        }
    }

    // Einstellungs Menü
    Dialog
    {
        id: settingDialog
        parent: mainWindow.contentItem

        title: "Einstellungen & Log"
        visible: false
        modal: true
        font: Theme.defaultFont

        z: 10000
        width: 390
        height: 440
        x: (parent.width - width) / 2
        y: (parent.height - height) / 2

        ScrollView
        {
            anchors.fill: parent
            contentWidth: parent.width
            contentHeight: columnContent.height

            ColumnLayout
            {
                id: columnContent
                width: parent.width
                spacing: 20
                anchors.margins: 20

                // ================= Settings Bereich =================
                ColumnLayout
                {
                    Layout.fillWidth: true
                    spacing: 10

                    Label { text: "Einstellungen"; font.bold: true; font.pointSize: 14 }
                    Rectangle { height: 1; color: "#888"; Layout.fillWidth: true }

                    // Server
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Server:"; Layout.preferredWidth: 80 }
                        TextField { id: serverField; Layout.fillWidth: true; placeholderText: "Adresse eingeben" }
                    }

                    // Name
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "Name:"; Layout.preferredWidth: 80 }
                        TextField { id: nameField; Layout.fillWidth: true; placeholderText: "Monteur-Name eingeben" }
                    }

                    // ApiToken
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "ApiToken:"; Layout.preferredWidth: 80 }
                        TextField { id: apiTkField; Layout.fillWidth: true; placeholderText: "ApiToken eingeben" }
                    }

                    // lastEditDateField
                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Label { text: "SyncDate:"; Layout.preferredWidth: 80 }
                        TextField { id: lastEditDateField; Layout.fillWidth: true; placeholderText: "Letzte Änderung"; readOnly: true }
                    }

                    // Buttons Settings
                    RowLayout
                    {
                        Layout.alignment: Qt.AlignHCenter
                        spacing: 20

                        Button
                        {
                            text: "Abbrechen"
                            onClicked: settingDialog.close()
                        }

                        Button
                        {
                            text: "Speichern"
                            onClicked:
                            {
                                saveSettings();
                            }
                        }
                    }
                }

                // ================= Log Bereich =================
                ColumnLayout
                {
                    Layout.fillWidth: true
                    spacing: 10

                    Label { text: "Log"; font.bold: true; font.pointSize: 14 }
                    Rectangle { height: 1; color: "#888"; Layout.fillWidth: true }

                    ScrollView
                    {
                        Layout.fillWidth: true
                        Layout.preferredHeight: 200

                        TextArea
                        {
                            id: logTextBox
                            wrapMode: Text.WordWrap
                            readOnly: true
                            text: ""
                            width: parent.width
                        }
                    }

                    RowLayout
                    {
                        Layout.fillWidth: true
                        spacing: 10

                        Button
                        {
                            text: "Verbindungstest"
                            Layout.fillWidth: true
                            onClicked: exportData()
                        }

                        Button
                        {
                            text: "Schließen"
                            Layout.fillWidth: true
                            onClicked: settingDialog.close()
                        }
                    }
                }
            }
        }
    }

    // Button Logfensters
    QfToolButton
    {
        id: logButton
        bgcolor: Theme.mainColor
        iconSource: Theme.getThemeVectorIcon("ic_info_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked:
        {
            mainWindow.displayToast("logButton wurde geklickt")

            getSettings()
            settingDialog.open()
        }
    }

    // Button Export
    QfToolButton
    {
        id: exportButton
        bgcolor: Theme.darkGray
        iconSource: Theme.getThemeVectorIcon("ic_info_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked:
        {
            mainWindow.displayToast("exportButton wurde geklickt")
            exportData()
        }
    }

    // Button Import
    /*QfToolButton
    {
        id: importButton
        bgcolor: Theme.lightGray
        iconSource: Theme.getThemeVectorIcon("ic_info_black_24dp")
        iconColor: Theme.mainColor
        round: true
        onClicked:
        {
            mainWindow.displayToast("importButton wurde geklickt")
            importData()
        }
    }*/

// ###################################################### FUNCTIONS ###################################################### //

    function exportData()
    {
        Logic.logToGui("Export gestartet...", 2);

        // Projektnamen auslesen
        var directory = qgisProject.fileName;
        var path = directory.split("/");
        var projectName = path[path.length - 1];

        // ####### Abruf der Schicht ####### //

        var layers = qgisProject.mapLayersByName("Hydrant_VN");
        var layer = layers.length > 0 ? layers[0] : null;

        if(layer)
        {
            Logic.logToGui("Projekt: " + projectName, 1);
            Logic.logToGui("Schicht gefunden: " + layer, 1);
        }

        if (layer.fields && layer.fields.names)
        {
            var fieldNames = layer.fields.names;
            Logic.logToGui("Abruf der aktuellen Schichten erfolgreich!", 2);
            Logic.logToGui("Feldnamen: " + fieldNames.join(", "), 1);
        }

        // ####### Abruf der Details ####### //

        Logic.logToGui("Details der Schicht werden abgerufen...", 2);

        var records = [];
        var id = 0;
        var maxID = 5;

        while(id < maxID)
        {
            const myObject = layer.getFeature(id);
            //getMaintenanceStatus(myObject, id); // Für´s updaten des Status (Falls nicht Serverabhänigkeit)

            const breakCheck = myObject.attribute("G3E_FID"); // Prüfung auf weitere IDs (Schleife beenden)
            if (!breakCheck)
            {
                Logic.logToGui("Alle verfügbaren Objekte gefunden... (" + id + ")", 2);
                break;
            }

            const filter = myObject.attribute("Wartung"); // Filterfunktion
            if (filter !== undefined)
            {
                const objektFields = myObject.fields;
                if (objektFields !== null)
                {
                    //Logic.logToGui("myObject objektFields.count: " + objektFields.count, 1);
                } else
                {
                    Logic.logToGui("Keine Felder gefunden...", 3);
                }

                // Daten aus den Feldern
                var fidValue = myObject.attribute("G3E_FID"); // #0
                var bezeichnungValue = myObject.attribute("BEZEICHNUN"); // #1
                var bezeichnung1Value = myObject.attribute("BEZEICHNUN_1"); // #2
                var bezeichnung2Value = myObject.attribute("BEZEICHNUN_2"); // #3
                var verwendungValue = myObject.attribute("VERWENDUNG"); // #4
                var ortslageValue = myObject.attribute("ORTSLAGE"); // #5
                var daemmaterValue = myObject.attribute("DAEMMATER"); // #6
                var verbindungValue = myObject.attribute("VERBINDUNG"); // #7
                var verlegetieValue = myObject.attribute("VERLEGETIE"); // #8
                var hoeheValue = myObject.attribute("HOEHE"); // #9
                var fabrikatioValue = myObject.attribute("FABRIKATIO"); // #10
                var baujahrValue = myObject.attribute("BAUJAHR"); // #11
                var inbetriebnrValue = myObject.attribute("INBETRIEBNR"); // #12
                var strassennuValue = myObject.attribute("STRASSENNU"); // #13
                var lage_zum_sValue = myObject.attribute("LAGE_ZUM_S"); // #14
                var vorschiebeValue = myObject.attribute("VORSCHIEBE"); // #15
                var entlueftunValue = myObject.attribute("ENTLUEFTUN"); // #16
                var schliessvoValue = myObject.attribute("SCHLIESSVO"); // #17
                var hinweisschValue = myObject.attribute("HINWEISSCH"); // #18
                var leistungValue = myObject.attribute("LEISTUNG"); // #19
                var gruppeValue = myObject.attribute("GRUPPE"); // #20
                var artValue = myObject.attribute("ART"); // #21
                var typValue = myObject.attribute("TYP"); // #22
                var materialValue = myObject.attribute("MATERIAL"); // #23
                var nennweiteValue = myObject.attribute("NENNWEITE"); // #24
                var innendurchValue = myObject.attribute("INNENDURCH"); // #25
                var aussendurchValue = myObject.attribute("AUSSENDURC"); // #26
                var nenndruckValue = myObject.attribute("NENNDRUCK"); // #27
                var motorantriValue = myObject.attribute("MOTORANTRI"); // #28
                var herstellerValue = myObject.attribute("HERSTELLER"); // #29
                var fabrikatValue = myObject.attribute("FABRIKAT"); // #30
                var lieferantValue = myObject.attribute("LIEFERANT"); // #31
                var sap_materiValue = myObject.attribute("SAP_MATERI"); // #32
                var einheitValue = myObject.attribute("EINHEIT"); // #33
                var preis_pro_Value = myObject.attribute("PREIS_PRO_"); // #34
                var nummerValue = myObject.attribute("NUMMER"); // #35
                var betriebdruckValue = myObject.attribute("BETRIEBDR"); // #36
                var ruhedruckValue = myObject.attribute("RUHEDRUCK"); // #37
                var adressnummValue = myObject.attribute("ADRESSNUMM"); // #38
                var statusValue_1 = myObject.attribute("STATUS"); // #39
                var herkunftValue = myObject.attribute("HERKUNFT"); // #40
                var eigentuemeValue = myObject.attribute("EIGENTUEME"); // #41
                var eigentue_1Value = myObject.attribute("EIGENTUE_1"); // #42
                var betreiber_Value = myObject.attribute("BETREIBER_"); // #43
                var betreiberValue = myObject.attribute("BETREIBER"); // #44
                var bemerkungValue = myObject.attribute("BEMERKUNG"); // #45
                var mandant_miValue = myObject.attribute("MANDANT_MI"); // #46
                var mandantValue = myObject.attribute("MANDANT"); // #47
                var lagegenauiValue = myObject.attribute("LAGEGENAUI"); // #48
                var dateValue = Logic.convertOnceDateFormat(myObject.attribute("SyncDate")); // #49
                var statusValue = myObject.attribute("Wartung"); // #50

                records.push
                ({
                    FID: fidValue,
                    bezeichnung: bezeichnungValue,
                    bezeichnung_1: bezeichnung1Value,
                    bezeichnung_2: bezeichnung2Value,
                    verwendung: verwendungValue,
                    ortslage: ortslageValue,
                    daemmater: daemmaterValue,
                    verbindung: verbindungValue,
                    verlegetie: verlegetieValue,
                    hoehe: hoeheValue,
                    fabrikatio: fabrikatioValue,
                    baujahr: baujahrValue,
                    inbetriebnr: inbetriebnrValue,
                    strassennu: strassennuValue,
                    lage_zum_s: lage_zum_sValue,
                    vorschiebe: vorschiebeValue,
                    entlueftun: entlueftunValue,
                    schliessvo: schliessvoValue,
                    hinweissch: hinweisschValue,
                    leistung: leistungValue,
                    gruppe: gruppeValue,
                    art: artValue,
                    typ: typValue,
                    material: materialValue,
                    nennweite: nennweiteValue,
                    innendurch: innendurchValue,
                    aussendurc: aussendurchValue,
                    nenndruck: nenndruckValue,
                    motorantri: motorantriValue,
                    hersteller: herstellerValue,
                    fabrikat: fabrikatValue,
                    lieferant: lieferantValue,
                    sap_materi: sap_materiValue,
                    einheit: einheitValue,
                    preis_pro_: preis_pro_Value,
                    nummer: nummerValue,
                    betriebdr: betriebdruckValue,
                    ruhedruck: ruhedruckValue,
                    adressnumm: adressnummValue,
                    status: statusValue_1,
                    herkunft: herkunftValue,
                    eigentueme: eigentuemeValue,
                    eigentue_1: eigentue_1Value,
                    betreiber_: betreiber_Value,
                    betreiber: betreiberValue,
                    bemerkung: bemerkungValue,
                    mandant_mi: mandant_miValue,
                    mandant: mandantValue,
                    lagegenaui: lagegenauiValue,
                    syncdate: dateValue,
                    wartung: statusValue
                });

            }

            if(dateValue === Logic.convertOnceDateFormat(new Date()))
            {
                settings.setValue("lasteditdate", Logic.convertOnceDateFormat(new Date()));
                settings.sync();
            }

            id++;
        }

        // ############### Daten sammeln & Speichern ############### //

        // Grunddaten
        var project = projectName;
        var user = settings.value("username", "");
        var token = settings.value("apitoken", "");
        var basicDate = settings.value("lasteditdate", "");

        // Speicherung aller zusammemgefassten Daten
        var basicDataList =
        {
            FID: fidValue,
            ProjectName: project,
            UserName: user,
            ApiToken: token,
            Syncdate: basicDate,
            Records: records
        };

        // ############### Daten sammeln & Speichern ############### //

        var serverAdress = settings.value("serveradress", "").toString();
        var jsonString = JSON.stringify(basicDataList);

        // Ausgabe
        Logic.logToGui("Daten wurden gespeichert...", 2);
        Logic.logToGui(jsonString, 1);

        // Serververbindung (Daten)
        Logic.serverConnection(serverAdress, jsonString);

    }

    function importData()
    {
        Logic.logToGui("Import gestartet...", 2);

        // ####### Abruf der Schicht ####### //

        var layers = qgisProject.mapLayersByName("TrafficSignals");
        var layer = layers.length > 0 ? layers[0] : null;

        if(layer)
        {
            //Logic.logToGui("Schicht gefunden: " + layer, 1);
        }

        if (layer.fields && layer.fields.names)
        {
            var fieldNames = layer.fields.names;
            //Logic.logToGui("Feldnamen: " + fieldNames.join(", "), 1);
        }

        // ####### Abruf der Details ####### //

        Logic.logToGui("Details der Schicht werden abgerufen...", 2);

        var dataList = [];
        var id = 0;
        let maxID = 100;

        while(true)
        {
            const myObject = layer.getFeature(id);

            const breakCheck = myObject.attribute("SyncDate"); // Prüfung auf weitere IDs (Schleife beenden)
            if (!breakCheck)
            {
                Logic.logToGui("Alle verfügbaren Objekte gefunden... (" + id + ")", 2);
                break;
            }

            const fields = layer.fields; // Klammern, weil es eine Funktion ist
            const idx = fields.indexFromName("Status");

            // Lokales Feature ändern (optional, für die Anzeige)
            myObject.setAttribute(idx, "off");

            // Änderung am Layer übernehmen
            layer.startEditing(); // Bearbeitungsmodus starten
            layer.changeAttributeValue(myObject.id, idx, "on");
            layer.commitChanges(); // Änderungen speichern

            id++;
        }
    }

    function saveBasicSettings()
    {
        var username = firstNameField.text;
        var apiToken = firstApiTkField.text;

        if(username && apiToken)
        {
            settings.setValue("username", username);
            settings.setValue("apitoken", apiToken);
            // Syncen um die Werte sicher in den Schlüsseln zu speichern
            settings.sync();
            firstSettingDialog.close()
            mainWindow.displayToast("Einstellungen wurden gespeichert!")
        }
        else
        {
            mainWindow.displayToast("Speichern fehlgeschlagen, alle Felder müssen ausgefüllt sein!")
        }
    }

    function saveSettings()
    {
        var serverName = serverField.text;
        var username = nameField.text;
        var apiToken = apiTkField.text;

        if(username && apiToken)
        {
            settings.setValue("serveradress", serverName);
            settings.setValue("username", username);
            settings.setValue("apitoken", apiToken);
            // Syncen um die Werte sicher in den Schlüsseln zu speichern
            settings.sync();
            settingDialog.close()
            mainWindow.displayToast("Einstellungen wurden gespeichert!")
        }
        else
        {
            mainWindow.displayToast("Speichern fehlgeschlagen, alle Felder müssen ausgefüllt sein!")
        }
    }

    function getSettings()
    {
        serverField.text = settings.value("serveradress", "");
        nameField.text = settings.value("username", "");
        apiTkField.text = settings.value("apitoken", "");
        lastEditDateField.text = settings.value("lasteditdate", "");
        settings.sync();
    }

    function getMaintenanceStatus(myObject, ID)
    {
        var layer = qgisProject.mapLayersByName("Hydrant_VN");
        const Item = myObject;

        var itemSyncDateStr = Item.attribute("SyncDate");
        var itemSyncDate = new Date(itemSyncDateStr);

        itemSyncDate.setMonth(itemSyncDate.getMonth() + 12);

        Logic.logToGui("Neues Ablaufdatum: " + itemSyncDate.toISOString(), 1);
    }
}
