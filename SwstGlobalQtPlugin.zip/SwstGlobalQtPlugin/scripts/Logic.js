// Ablauf zum setzen eines Loggers #LOG#
var logCallback = null;

function setLogCallback(callback)
{
    logCallback = callback;
}

function logToGui(message, status)
{
    if (logCallback)
    {
        logCallback(setLogText(message, status));
    }
}

function setLogText(message, status)
{
    if(typeof status == "number")
    {
        switch(status)
        {
        case 1:
            return getLogStamp() + " - [INFO] " + message;
        case 2:
            return getLogStamp() + " - [WARNING] " + message;
        case 3:
            return getLogStamp() + " - [ERROR] " + message;
        default:
            return getLogStamp() + " - [UNKNOWN] " + message;
        }
    }
    else
    {
        return getLogStamp() + " - [ERROR] Fehler bei der Logausgabe aufgetreten!";
    }
}

function getLogStamp()
{
    var date = new Date();

    return date.toLocaleDateString("de-DE")
}

function getTimeStamp(str)
{
    var d = new Date(str);
    if (isNaN(d.getTime())) return null; // ungültiges Datum -> null zurück

    return d.toLocaleString("de-DE");
}

function toIsoDateTime(str)
{
    // Beispielinput: "9/30/2025 3:28:00 PM"
    const match = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4}) (\d{1,2}):(\d{2}):(\d{2}) (AM|PM)$/);
    if (!match) return null;

    let [_, month, day, year, hour, minute, second, period] = match;

    month = parseInt(month);
    day = parseInt(day);
    year = parseInt(year);
    hour = parseInt(hour);
    minute = parseInt(minute);
    second = parseInt(second);

    if (period === 'PM' && hour !== 12) hour += 12;
    if (period === 'AM' && hour === 12) hour = 0;

    const iso = `${year.toString().padStart(4, '0')}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}T${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}:${second.toString().padStart(2, '0')}`;
    return iso;
}

function serverAvailable()
{
    // Create a http httpRequest
    var httpRequest = new XMLHttpRequest();
    var serverAdress = "https://vmdev2.swst.de/DNNDEV/";

    // Open the Connection to the Server
    httpRequest.open("GET", serverAdress, true);
    httpRequest.timeout = 15000;

    httpRequest.setRequestHeader("Content-Type", "application/json");

    logToGui("Server: " + serverAdress, 1);
    logToGui("Verbindung zum Server wird hergestellt...", 1);

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === httpRequest.DONE)
        {
            if (httpRequest.status === 200)
            {
                logToGui("Serververbindung erfolgreich!", 1);
            } else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.statusText, 1);
            }
        }
    };

    httpRequest.send();

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
    };
}

function connectData(serverAdress, token, jsonString)
{
    var newAdress = serverAdress + "QFieldData/";

    // Create a http httpRequest
    var httpRequest = new XMLHttpRequest();

    httpRequest.open("POST", newAdress, true);
    httpRequest.timeout = 15000;

    httpRequest.setRequestHeader("Content-Type", "application/json");
    httpRequest.setRequestHeader("Authorization", "Bearer " + token);

    httpRequest.onreadystatechange = function()
    {
        if (httpRequest.readyState === XMLHttpRequest.DONE)
        {
            if (httpRequest.status >= 200 && httpRequest.status <= 405)
            {
                logToGui("Verbindung erfolgreich hergestellt!", 1);
                logToGui("Status: " + httpRequest.status + " " + httpRequest.statusText, 1);
                logToGui("Antwort: " + httpRequest.responseText, 1);

                var response = JSON.parse(httpRequest.responseText);
                var records = response.Records;

                applyServerUpdates(records);
            }

            else
            {
                logToGui("Verbindung fehlgeschlagen: " + httpRequest.status, 3);
                logToGui("Antwort: " + httpRequest.statusText, 1);
            }
        }
    };

    httpRequest.send(jsonString);

    httpRequest.ontimeout = function()
    {
        logToGui("Verbindung fehlgeschlagen, time out...", 3);
    };
}



